package week1.day1;

public class LearnVariables {

	public static void main(String[] args) {
		// Primitive datatypes
		// datatype variableName = value
		// byte, short, int, long
		byte seatingCapacity = 5;
		int carPrice = 800000;
		long ownerNumber = 9345658249L;
		
		// decimal - float, double
		float mileage = 20.5f;
		
		// character - char
		char engine = 'P';
		
		// boolean - true/ false
		boolean preOwned = false;
		
		// text - sequence of characters
		String color = "Red";
		
		
		System.out.println(preOwned);
		
		
		
		
		
		
		
		
		
		
	}

}
