package week3.day2;

public interface Cibil extends RBI{

	void creditScore();
	
	void maxLoanAmount();
}
