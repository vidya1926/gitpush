package week3.day2;

public class IOBChennai extends IOB{
	public void minBalance() {

	}
	public static void main(String[] args) {
		RBI bank = new IOBChennai();
		bank.minimumBalance();
		bank.maxLoanAmount();
//		bank.minBalance();
//		bank.maxLoan();
	}
	public void minimumBalance() {
		
	}
	public void maxLoanAmount() {
		
	}

}
