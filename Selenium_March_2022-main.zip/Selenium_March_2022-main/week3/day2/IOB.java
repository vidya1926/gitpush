package week3.day2;

public abstract class IOB implements RBI{
	
	public abstract void minBalance();
	
	public void maxLoan() {
		System.out.println(100000);
	}
	
	

	public static void main(String[] args) {
//		IOB bank = new IOB();
	}

}
