package week3.day1;

public class Audi extends Car{

	public static void main(String[] args) {
		Audi audi = new Audi();
		audi.applyBrake();
	}
}
